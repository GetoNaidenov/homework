package hero;

public class Knight extends Hero {
    protected Knight(String name, int level) {
        super(name, level);
    }
    public String getName(){
        return super.getName();
    }
    public int getLevel(){
        return super.getLevel();
    }
}
