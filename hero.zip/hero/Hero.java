package hero;

public class Hero {
    private String name;
    private int level;

    protected Hero(String name, int level){
        this.name = name;
        this.level = level;
    }
    protected String getName(){
        return this.name;
    }
    protected int getLevel(){
        return this.level;
    }

    @Override
    public String toString(){
        return String.format("Type: %s Username: %s Level: %s",
                this.getClass().getName(),
                 this.getName(),
                  this.level);
    }

}
