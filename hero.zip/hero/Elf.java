package hero;

public class Elf extends Hero {
    public Elf(String name, int level) {
        super(name, level);
    }

    public String getName(){
        return super.getName();
    }
    public int getLevel(){
        return super.getLevel();
    }


}
