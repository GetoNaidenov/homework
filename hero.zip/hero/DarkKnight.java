package hero;

public class DarkKnight extends Knight {
    protected DarkKnight(String name, int level) {
        super(name, level);
    }
    public String getName(){
        return super.getName();
    }
    public int getLevel(){
        return super.getLevel();
    }
}
