package hero;

public class SoulMaster extends DarkWizard {
    public SoulMaster(String name, int level) {
        super(name, level);
    }
    public String getName(){
        return super.getName();
    }
    public int getLevel(){
        return super.getLevel();
    }
}
