package hero;

public class Wizard extends Hero {
    protected Wizard(String name, int level) {
        super(name, level);
    }
    public String getName(){
        return super.getName();
    }
    public int getLevel(){
        return super.getLevel();
    }
}
