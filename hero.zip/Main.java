
import hero.BladeKnight;
import hero.Elf;
import hero.MuseElf;
import hero.SoulMaster;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Elf bloodElf = new Elf("Petq",26);
        MuseElf elf = new MuseElf("Ghetto", 24);

        SoulMaster wizard = new SoulMaster("pesho",50);
        BladeKnight knight = new BladeKnight("tosho", 2);

        System.out.println(wizard);
        System.out.println(wizard.getLevel());
        System.out.println(knight);
    }

}
