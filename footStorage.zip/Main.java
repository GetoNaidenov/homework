
import foodShortage.*;

import java.io.IOException;
import java.util.*;

public class Main {

    public static void main(String[] args)throws IOException {
        Scanner scanner = new Scanner(System.in);

        Map<String, Buyer> people = new HashMap<>();

        int n = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < n ; i++) {

            String[] citAndReb = scanner.nextLine().split(" ");
            String name = citAndReb[0];
            if (citAndReb.length == 3){
                Rebel rebel = new Rebel(citAndReb[0],Integer.parseInt(citAndReb[1]),citAndReb[2]);
                people.put(name,rebel);
            }else {
                Citizen citizen = new Citizen(citAndReb[0],Integer.parseInt(citAndReb[1]),citAndReb[2],citAndReb[3]);
                people.put(name,citizen);
            }
        }

        String input = scanner.nextLine();

        while (!input.equals("End")){

            if (people.containsKey(input)){
                people.get(input).buyFood();
            }
            input = scanner.nextLine();
        }

        int maxFood = 0;

        for (Buyer entry: people.values()) {
          maxFood += entry.getFood();
        }

        System.out.println(maxFood);



    }
    }

