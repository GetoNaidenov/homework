package models;

import enums.CardPower;
import enums.CardSuit;

public class Card {
    private CardPower power;
    private CardSuit suit;


    public Card(CardPower power,CardSuit suit){
        this.power = power;
        this.suit = suit;

    }

    private int calculatePower(){
        return this.power.getValue() + this.suit.getValue();
    }

    @Override
    public String toString(){
        String format = String.format(
                "Card name: %s of %s; Card power: %d",
                this.power.toString(),
                this.suit.toString(),
                this.calculatePower()
        );
        return format;
    }


}
