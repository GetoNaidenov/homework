import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        ConsoleReader reader = new ConsoleReader();

        int[] dimestions = InputParser.parseIntegerArray(reader.readLine());

        int rols = dimestions[0];
        int cols = dimestions[1];

        Galaxy galaxy = new Galaxy(new Field(new int [rols][cols]));

         Enemy enemy = new Enemy(galaxy);
         Player player = new Player(galaxy);
              Engine engine = new Engine(reader,enemy,player)  ;
              engine.run();

        System.out.println(player.getPoints());

    }
}