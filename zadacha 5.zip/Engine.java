
public class Engine {
    private ConsoleReader reader;
    private Enemy enemy;
    private Player player;
    private String command;

    public Engine(ConsoleReader reader,Enemy enemy,Player player){
        this.reader = reader;
        this.enemy = enemy;
        this.player = player;
        this.command = "";
    }

    public void run(){
        this.command = this.reader.readLine();
        while (!command.equals("Let the Force be with you")) {

            int[] playerPosition = InputParser.parseIntegerArray(this.command);
            int[] enemiPosition = InputParser.parseIntegerArray(this.reader.readLine());

            int enemiRow = enemiPosition[0];
            int enemiCol = enemiPosition[1];

           enemy.destroyStars(enemiRow,enemiCol);

            int playerRow = playerPosition[0];
            int playerCol = playerPosition[1];

            this.player.collectStars(playerRow,playerCol);

           this.command = reader.readLine();
        }
    }
}
