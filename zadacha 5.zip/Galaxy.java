public class Galaxy {
    private Field field;

    public Galaxy(Field field){
        this.field = field;
    }
    public int getLenght(){
        return this.field.getLenght();
    }
    public int getInnerLenght(int dimension){
        return this.field.getDimensionLenght(dimension);
    }
    public void setStar(int row,int col,int newValue){
        this.field.setCell(row,col,newValue);
    }

    public long getStar(int row, int col) {
        return this.field.getCell(row,col);
    }
}
