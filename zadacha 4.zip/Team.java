import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Team {
    private String name;
    private List<Person> first;
    private List<Person> reserve;

    public Team(String name) {
        this.name = name;
        this.first = new ArrayList<>();
        this.reserve = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void addPlayer(Person player){
        if (player.getAge()< 40){
            this.first.add(player);
        }else {
            this.reserve.add(player);
        }
    }



    public List<Person> getFirst() {
        return Collections.unmodifiableList( first);
    }

    public List<Person> getReserve() {
        return Collections.unmodifiableList(reserve);
    }
}
