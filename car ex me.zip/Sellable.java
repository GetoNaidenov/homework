public interface Sellable {
    double getPrice();
}
