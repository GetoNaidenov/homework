public interface Rentable {
    int getMinRentDay();
    double getPricePerDay();

}
