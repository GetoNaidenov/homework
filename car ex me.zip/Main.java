
import java.io.IOException;
import java.util.*;

public class Main {

    public static void main(String[] args)throws IOException {
        Scanner scanner = new Scanner(System.in);

        CarImpl seat = new Seat("Leon","Gray",110,"Spain",11111.1);
        CarImpl audi = new Audi("A4","Gray",110,"Germany",3,99.9);

        System.out.println(String.format("%s is %s color and have %s horse power",
                seat.getModel(),
                seat.getColor(),
                seat.getHorsePower()));
        System.out.println(seat.toString());

        System.out.println(String.format("%s is %s color and have %s horse power",
                audi.getModel(),
                audi.getColor(),
                audi.getHorsePower()));
        System.out.println(audi.toString());

    }
    }

