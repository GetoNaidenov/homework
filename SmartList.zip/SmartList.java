import java.util.Arrays;

public class SmartList {
    private static final int INITIAL_CAPACITY = 4;

    private int[]data;
    private int size;

    public SmartList(){
        this.data = new int[INITIAL_CAPACITY];
        this.size = 0;
    }

    public int size(){
        return this.size;
    }

    public void add(int element){
        if (this.size == this.data.length){
            reSize();
        }
        this.data[this.size++] = element;
}

    private void reSize() {
        int[] newData = new int[this.data.length * 2];

        for (int i = 0; i <this.data.length ; i++) {
            newData[i] = this.data[i];
        }
        this.data = newData;
    }
     public int remove(int index){
        int element = this.data[index];
         for (int i = index; i <this.size -1 ; i++) {
             this.data[i] = this.data[i+1];
         }
        this.data[this.size--] = 0;
        return element;
}
    public boolean contains(int element){
        for (int i = 0; i <this.size ; i++) {
            if (element == this.data[i]){
                return true;
            }
        }
        return false;
    }

    public void swap(int first,int second){
        int temp = this.data[first];
        this.data[first] = this.data[second];
        this.data[second] = temp;
    }

    public int countGreaterThan(int element){
        return (int) Arrays.stream(this.data,0,this.size)
                .filter(e -> e> element)
                .count();
    }

    public int getMax(){
        return Arrays.stream(this.data,0,this.size)
                .max().orElse(Integer.MIN_VALUE);
    }

    public int getMin(){
        return Arrays.stream(this.data,0,this.size)
                .min().orElse(Integer.MAX_VALUE);
    }







}
