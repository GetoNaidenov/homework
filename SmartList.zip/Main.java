import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

   Scanner scanner = new Scanner(System.in);

   SmartList numbers = new SmartList();

   String line = scanner.nextLine();

   while (!line.equals("END")){

       String[]tokens = line.split("\\s+");
       



       line = scanner.nextLine();
   }

    }
}
