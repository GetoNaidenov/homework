package footballTeamGenerator;

public class Player {
    private String name;
    private int endurance;
    private int sprint;
    private int dribble;
    private int passing;
    private int shooting;

    public Player(String name, int endurance, int sprint, int dribble, int passing, int shooting) {
        this.setName(name);
        this.setEndurance(endurance);
        this.setSprint(sprint);
        this.setDribble(dribble);
        this.setPassing(passing);
        this.setShooting(shooting);
    }

    public int overallSkillLevel(){
        int points =((this.endurance
                         + this.sprint
                          + this.dribble
                           + this.passing
                            + this.shooting) / 5);

        return points;
    }
    private void setEndurance(int endurance) {
        if (checkStatus(endurance)) {
            this.endurance = endurance;
        } else {
            throw new IllegalArgumentException("Endurance should be between 0 and 100.");
        }
    }
    private boolean checkStatus(int stats) {
        boolean check = false;
        if (stats >= 0 && stats <= 100) {
            check = true;
        }
        return check;
    }
    private void setSprint(int sprint) {
        if (checkStatus(sprint)) {
            this.sprint = sprint;
        } else {
            throw new IllegalArgumentException("Sprint should be between 0 and 100.");
        }
    }
    private void setDribble(int dribble) {
        if (checkStatus(dribble)) {
            this.dribble = dribble;
        } else {
            throw new IllegalArgumentException("Dribble should be between 0 and 100.");
        }
    }

    private void setPassing(int passing) {
        if (checkStatus(passing)) {
            this.passing = passing;
        } else {
            throw new IllegalArgumentException("Passing should be between 0 and 100.");
        }

    }

    private void setShooting(int shooting) {
        if (checkStatus(shooting)) {
            this.shooting = shooting;
        } else {
            throw new IllegalArgumentException("Shooting should be between 0 and 100");
        }
    }

    private void setName(String name) {
        if (name.trim().isEmpty()) {
            throw new IllegalArgumentException("A name should not be empty.");
        }
        this.name = name;
    }

    public String getName() {
        return name;
    }
}