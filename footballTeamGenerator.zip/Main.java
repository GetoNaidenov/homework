import footballTeamGenerator.Player;
import footballTeamGenerator.Team;

import java.io.IOException;
import java.util.*;

public class Main {

    public static void main(String[] args)throws IOException {
        Scanner scanner = new Scanner(System.in);

        Team team = null;

        String input = scanner.nextLine();
         while (!input.equals("END")){

             String[] commands = input.split(";");

             String command = commands[0];
             String teamName = commands[1];
             switch (command){
                 case "Team":
                    team = new Team(teamName);
                     break;
                 case "Add":
                     teamName = commands[1];
                     if (team.getName().equals(teamName)){
                         try {
                             String playerName = commands[2];
                             int endurance = Integer.parseInt(commands[3]);
                             int sprint = Integer.parseInt(commands[3]);
                             int dribble = Integer.parseInt(commands[3]);
                             int passing = Integer.parseInt(commands[3]);
                             int shooting = Integer.parseInt(commands[3]);
                             Player pl = new Player(playerName,endurance,sprint,dribble,passing,shooting);

                            team.addPlayer(pl);
                         }catch (IllegalArgumentException e){
                             System.out.println(e.getMessage());
                         }
                     }else {
                         System.out.printf("Team %s does not exist%n",teamName);
                     }
                     break;
                 case "Remove":
                     if (team.getName().equals(teamName)){
                         team.removePlayer(commands[2]);
                     }
                  break;
                 case "Rating":
                     if (team.getName().equals(teamName)){
                         System.out.printf("%s - %d%n",team.getName(),team.getRaiting());
                     }else {
                         System.out.printf("Team %s does not exist.",teamName);
                     }
                     break;
             }
             input = scanner.nextLine();
         }
    }
    }

