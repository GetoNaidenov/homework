
import java.io.IOException;
import java.util.*;

public class Main {

    public static void main(String[] args)throws IOException {
        Scanner scanner = new Scanner(System.in);

        List<Identifiable> robots = new ArrayList<>();

        String input = scanner.nextLine();

        while (!input.equals("End")){

            String[] comands = input.split(" ");

            if (comands.length == 2){
                Robot robot = new Robot(comands[0],comands[1]);
                robots.add(robot);
            }else {
                Citizen citizen = new Citizen(comands[0],Integer.parseInt(comands[1]),comands[2]);
                robots.add(citizen);
            }
            input = scanner.nextLine();
        }
        String fakeId = scanner.nextLine();

       robots.stream()
               .filter(s -> s.getId().endsWith(fakeId))
               .forEach(s -> System.out.println(s.getId()));




    }
    }

