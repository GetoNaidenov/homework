import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

 MathOperation m = new MathOperation();
        System.out.println(m.add(2,2));
        System.out.println(m.add(3,3,3));
        System.out.println(m.add(4,4,4,4));


    }
}
