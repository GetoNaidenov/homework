import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       int numberOfCars = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i <numberOfCars ; i++) {
            Car car = new Car();
         String[] carPats =   scanner.nextLine().split(" ");
            car.setMake(carPats[0]);
            car.setModel(carPats[1]);
            car.setHorsePower(Integer.parseInt(carPats[2]));

            System.out.println(car.carInfo());
        }








    }
}
