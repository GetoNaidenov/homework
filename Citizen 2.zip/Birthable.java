public interface Birthable {
    String getBirthable();
}
