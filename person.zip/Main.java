
import person.Bulgarian;
import person.Chinese;
import person.European;
import person.Person;

import java.util.*;


public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Person> persons = new ArrayList<>();

        persons.add(new Bulgarian("pesho"));
        persons.add(new European("pesho"));
        persons.add(new Chinese("pesho"));

        for (Person person:persons) {
            print(person);
        }

    }
    private static void print(Person person){
        System.out.println(person.sayHello());
    }

}
