public class Chocken {
    private String name;
    private int age;

    public Chocken(String name, int age){
        this.setName(name);
        this.setAge(age);
    }


    private void setName(String name){
        if (name.length()<= 0){
            System.out.println("Name cannot be empty.");
            this.name = name;
        }else {
            this.name = name;
        }
    }
    private void setAge(int age){
        if (age > 15 || age <= 0){
            System.out.println("Age shold be between 0 and 15.");
            this.age = age;
        }else {
            this.age = age;
        }
    }

    public double productPerDay(){
        return calculateProductedPerDay();

    }


    private double calculateProductedPerDay(){
        double egg = 0;
        if (this.age < 6){
            egg = 2;
        }else if (this.age < 12){
            egg = 1;
        }else {
            egg = 0.75;
        }
        return egg;
    }

    @Override
    public String toString() {
        if (this.age > 0 && this.age <= 15) {
            return String.format("Chicken %s (%d) can produce %.2f eggs per day.", this.name, this.age, this.productPerDay());
        }
        return String.format("Chiken is dead");
    }
}
