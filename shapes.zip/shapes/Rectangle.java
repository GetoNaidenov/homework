package shapes;

public class Rectangle extends Shape{
    private Double width;
    private Double height;

    public Rectangle(Double width, Double height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public Double calculatePerimeter() {
      Double perimetr =  this.height * 2 + this.width * 2;
      super.setPerimeter(perimetr);
        return perimetr;
    }

    @Override
    public Double calculateArea() {
        Double area = this.width * this.height;
        super.setArea(area);
        return area;
    }



}
