import shapes.Circle;
import shapes.Rectangle;
import shapes.Shape;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Shape shape = new Rectangle(5.0, 10.0);
        Shape circle = new Circle(3.0);
        
        System.out.println(shape.calculateArea());
        System.out.println(circle.calculateArea());
    }
}
