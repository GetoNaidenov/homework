package borderControl;

public interface Identifiable {
    String getId();
}
