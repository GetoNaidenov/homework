import borderControl.Citizer;
import borderControl.Identifiable;
import borderControl.Robot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String>ids = new ArrayList<>();

         String line = scanner.nextLine();

         while (!line.equals("End")){
             String[] parts = line.split(" ");

             if (parts.length == 2){
             ids.add( parts[1]);

             }else {
               ids.add(parts[2]);
             }
             line = scanner.nextLine();
         }

        String fakeIdEndingOn = scanner.nextLine();

         ids.stream()
                 .filter(s -> s.endsWith(fakeIdEndingOn))
                 .forEach(System.out::println);

    }

}
