import java.util.ArrayList;
import java.util.List;

public class Box<T> {
        private T element;
        private List<T> data;

        public Box(){
            this.element = element;
            this.data = new ArrayList<>();
        }
        public void add(T ele){
            this.data.add(ele);
        }

        public void swap(int[] indexs){
            int firstIndex = indexs[0];
            int secondIndex = indexs[1];

            T firstElement = this.data.get(firstIndex);
            T secondElement = this.data.get(secondIndex);

            this.data.set(firstIndex,secondElement);
            this.data.set(secondIndex,firstElement);
        }


        @Override
        public String toString(){
            String txt = "";
            for (T ele:this.data) {
                txt += String.format(ele.getClass().getName() +": "+ele+ "%n");
            }
            return txt;
        }

    }


