import java.util.HashMap;
import java.util.Map;

public class PriceCalculator {
    private double priceOfDay;
    private int days;
    private String season;
    private String discount;

    Map<String,Integer> seazonMultipler = new HashMap<>();


    public PriceCalculator(double priceOfDay,int days,String season,String discount){
        this.priceOfDay = priceOfDay;
        this.days = days;
        this.season = season;
        this.discount = discount;
        seazonMultipler.put("Autumn",1);
        seazonMultipler.put("Spring",2);
        seazonMultipler.put("Winter",3);
        seazonMultipler.put("Summer",4);
    }

    public double totalPrice(){
        double price = 0;

        price = priceOfDay * days;

        if (seazonMultipler.containsKey(this.season)){
            price = price * seazonMultipler.get(this.season);
        }

        if (discount.equals("VIP")){
            price -= (price * 1.2) - price;
        }else if (discount.equals("SecondVisit")){
            price -= (price * 1.1) - price;
        }

        return price;
    }




}
