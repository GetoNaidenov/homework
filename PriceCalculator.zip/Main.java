import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        String[] command = scanner.nextLine().split(" ");
        double price = Double.parseDouble(command[0]);
        int days  = Integer.parseInt(command[1]);
        String season = command[2];
        String discount = command[3];

        PriceCalculator priceCalculator = new PriceCalculator(price,days,season,discount);

        System.out.printf("%.2f",priceCalculator.totalPrice());

    }
}