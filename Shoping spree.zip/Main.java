import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Map<String,Person> personMap = new LinkedHashMap<>();
        Map<String,Product> productMap = new HashMap<>();

        String[]persons = scanner.nextLine().split(";");

        for (int i = 0; i < persons.length; i++) {
            String[]nameAndMoney = persons[i].split("=");
            String name = nameAndMoney[0];
            double money = Double.parseDouble(nameAndMoney[1]);

            Person person = new Person(name,money);
            personMap.put(name,person);
        }

        String[]products = scanner.nextLine().split(";");

        for (int i = 0; i <products.length ; i++) {
            String[]productAndPrice = products[i].split("=");
            String name = productAndPrice[0];
            double price = Double.parseDouble(productAndPrice[1]);

            Product product = new Product(name,price);
            productMap.put(name,product);
        }
        String input = scanner.nextLine();

        while (!input.equals("END")){

           String[] command = input.split("\\s+");
           String name = command[0];
           String product = command[1];

           personMap.get(name).buyProduct(productMap.get(product));

            input = scanner.nextLine();
        }

        for (Map.Entry<String,Person >person:personMap.entrySet()) {
            System.out.println( person.getValue().toString());
        }



    }
}
