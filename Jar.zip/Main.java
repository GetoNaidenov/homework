package Jar;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Jar<Integer> jar = new Jar();

        jar.add(5);
        jar.add(7);
        jar.add(6);
        jar.add(8);

        System.out.println(jar.remove());
    }
    }

