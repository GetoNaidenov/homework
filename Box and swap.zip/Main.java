import java.util.*;

public class Main {
    public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);

                int n = Integer.parseInt(scanner.nextLine());

        List<Box<String>> boxes = new ArrayList<>();

                while (n-- > 0){
                   Box<String>box = new Box<>(scanner.nextLine());

                    boxes.add(box);
                }
                 int first = scanner.nextInt();
                 int second = scanner.nextInt();
                 swapBoxes(boxes,first,second);

        for (Box box:boxes) {
            System.out.println(box);
        }



            }
            public static <T> void swapBoxes(List<Box<T>> container,int first,int second) {
                Collections.swap(container,first,second);
            }
}

