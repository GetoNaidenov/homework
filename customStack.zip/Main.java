import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

     CustomStack stack = new CustomStack();

     stack.push(34);
     stack.push(3);
     stack.push(4);
     stack.push(39);

        System.out.println(stack.peek());
        System.out.println(stack.getSize());
        System.out.println(stack.pop());

    }
}
