import java.util.ArrayList;
import java.util.List;

public class SpaceStation {
    private String name;
    private int capacity;
    private List<Astronaut> data;

    public SpaceStation(String name,int capacity){
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public String getName(){
        return this.name;
    }
    public int getCapacity(){
        return this.capacity;
    }
    public int getCount(){
        return this.data.size();
    }
    public void add(Astronaut astronaut){
        if (this.data.size() < this.capacity){
            this.data.add(astronaut);
        }
    }
    public  boolean remove(String name){
        boolean removed = false;

        for (Astronaut astronaut:this.data) {
            if (astronaut.getName().equals(name)){
                removed = true;
            }
        }
        return removed;
    }

    public Astronaut getOldestAstronaut(){

        Astronaut oldAstronaut = new Astronaut("" ,0,"");

        for (Astronaut ast:this.data) {
             if (ast.getAge() > oldAstronaut.getAge()){
                 oldAstronaut = ast;
             }
        }
        return oldAstronaut;
    }

      public Astronaut getAstronaut(String name){

        Astronaut ast = new Astronaut("", 0,"");

          for (Astronaut astronaut:this.data) {
              astronaut.getName().equals(name);
              ast = astronaut;
          }
        return ast;
      }


     public String report(){
        String txt = "";

        txt += String.format("Astronauts working at Space Station %s:%n",this.name);
         for (Astronaut astronaut:this.data) {
             txt += astronaut.toString();
         }
         return txt;
     }



}
