import java.util.ArrayList;
import java.util.List;

public class Smartphone implements Callable,Browsable {
    private List<String> numbers;
    private List<String> urls;

    public Smartphone(List<String> numbers, List<String> urls){
        this.numbers = numbers;
        this.urls = urls;
    }


    @Override
    public String browse() {
        String txt = "";
        for (String url : urls) {
            boolean cifra = false;
            char[] ur = url.toCharArray();
            for (int i = 0; i < ur.length; i++) {
                char smar = ur[i];
                if (Character.isDigit(smar)) {
                    cifra = true;
                }
            }
            if (cifra != true) {
                txt += String.format("Browsing: %s!%n", url);
            } else {
                txt += String.format("Invalid URL!%n");
            }


        }
            return txt;
        }

    @Override
    public String call() {
        String txt = "";

        for (String call:numbers) {
            txt += String.format("Calling...%s%n",call);
        }

        return txt;
    }
}
