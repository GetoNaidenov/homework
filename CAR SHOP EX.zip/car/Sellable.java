package car;

public interface Sellable {
    Double getPrice();

}
