public class Cymric {
    private String name;
    private double furLengh;

    public Cymric(String name,double furLengh){
        this.name = name;
        this.furLengh = furLengh;
    }
    @Override
    public String toString(){
        return String.format("Cymric %s %.2f",this.name,this.furLengh);
    }
}
