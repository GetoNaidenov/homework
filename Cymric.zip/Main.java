
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String line = scanner.nextLine();

        Map<String, Siamese> siamese = new HashMap<>();
        Map<String, Cymric> cymric = new HashMap<>();
        Map<String, StreetExtraordinaire> street = new HashMap<>();

        while (!line.equals("End")) {

            String[] tokens = line.split(" ");
            String name = tokens[1];
            double specialParm = Double.parseDouble(tokens[2]);
            if (line.contains("Siamese")) {
                Siamese cat = new Siamese(name, specialParm);
                siamese.put(name, cat);
            } else if (line.contains("Cymric")) {
                Cymric cat = new Cymric(name, specialParm);
                cymric.put(name, cat);
            } else {
                StreetExtraordinaire cat = new StreetExtraordinaire(name, specialParm);
                street.put(name, cat);
            }
            line = scanner.nextLine();
        }
        String name = scanner.nextLine();

        if (siamese.containsKey(name)) {
            System.out.println(siamese.get(name).toString());
        } else if (cymric.containsKey(name)) {
            System.out.println(cymric.get(name).toString());
        } else {
            System.out.println(street.get(name).toString());
        }
    }
    }

