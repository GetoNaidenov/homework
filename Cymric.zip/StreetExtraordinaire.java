public class StreetExtraordinaire {

    private  String name;
    private double decibelsOfMeows;


    public StreetExtraordinaire(String name ,double decibelsOfMeows){
        this.name = name;
        this.decibelsOfMeows = decibelsOfMeows;
    }

    @Override
    public String toString(){
        return String.format("StreetExtraordinaire %s %.2f",this.name,this.decibelsOfMeows);
    }


}
