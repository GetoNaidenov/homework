
import zoo.Bear;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Bear bear = new Bear("Whithe");


        System.out.println(bear.getName());
    }
}
