import java.util.ArrayList;

public class Stack {
    private ArrayList<String> data;

    public Stack(){
        this.data = new ArrayList<>();
    }

    public void push(String element){
        this.data.add(element);
    }
    public String pop(){
        String pov = this.data.remove(this.data.size() -1);
        return pov;
    }
    public String peek(){
        return this.data.get(this.data.size() -1);
    }
    public boolean isEmpty(){
        boolean empty =  true;
        if (this.data.size() > 0){
            empty = false;
        }
        return empty;
    }

}
